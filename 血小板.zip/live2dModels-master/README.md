# 血小板以及pio（随机换装）模型

### 模型下载

自行整理的，修改了血小板的事件触发范围，以及pio的随机换装。有需要的朋友可以下载使用。

演示地址： [www.litblc.com/archives/722][1]

### 使用方式

 - 参考demo.html,将需要的文件引入
 - 注意引入路径，按照实际情况修改（注意waifu.js中的message.json路径也要修改）
 - 如果出现进入新页面canvas错乱的问题，查看是否使用了pjax，不支持
 - 自行修改message.json



  [1]: https://www.litblc.com/archives/772.html
